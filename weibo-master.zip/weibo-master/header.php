<html lang="it">
<head>
<meta content="text/html; charset=UTF-8" http-equiv="content-type">
<title>微博</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="page">
<div id="header">
<a href="https://github.com/shenjihehe"><img style="border:none" src="logo.png" width="192" height="85" alt="weobo"></a>
