# weibo

## 基于php+redis+mysql 
## 实现微博基本功能
## 热数据写入redis，冷数据写入mysql(如个人微博设置位1000条后为冷数据)
## 微博推送使用推拉模型
