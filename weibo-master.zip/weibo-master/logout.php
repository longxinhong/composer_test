<?php 

setcookie('username','',-1);
setcookie('userid','',-1);
setcookie('authsecret','',-1);

header('location:index.php');
exit;


?>