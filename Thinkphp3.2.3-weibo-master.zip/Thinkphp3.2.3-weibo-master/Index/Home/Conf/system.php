<?php  
 return array (
  'FILTER' => 
  array (
    0 => '后盾',
    1 => '论坛',
  ),
  'WEBNAME' => 'Edward微博',
  'COPY' => '粤ICP备10027771号-2',
  'REGIS_ON' => '1',
);  
?>